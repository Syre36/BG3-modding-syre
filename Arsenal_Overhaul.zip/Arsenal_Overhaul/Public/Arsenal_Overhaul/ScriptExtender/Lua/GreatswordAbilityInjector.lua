-- GreatswordAbilityInjector.lua
-- Adds Rush_SpringAttack when a greatsword is equipped, removes it when unequipped
-- Requires BG3 Script Extender v0.7.3

local function logMessage(message)
    Ext.Utils.Print("[Arsenal_Overhaul] " .. message)
end

logMessage("Initializing GreatswordAbilityInjector.lua")

local VANILLA_SPELL = "Rush_SpringAttack"

-- Check if an item is a greatsword
local function IsGreatsword(itemHandle)
    if not itemHandle then
        logMessage("Error: Invalid item handle")
        return false
    end
    local item = Ext.Entity.GetItem(itemHandle)
    if not item then
        logMessage("Error: Item not found for handle " .. tostring(itemHandle))
        return false
    end

    local weaponType = item.Weapon and item.Weapon.WeaponType or "Unknown"
    local isGreatsword = weaponType == "Greatsword"
    logMessage("Checking item " .. (item.Data and item.Data.Name or tostring(itemHandle)) .. ": isGreatsword=" .. tostring(isGreatsword))
    return isGreatsword
end

-- Add the spell to a character
local function AddSpell(characterHandle)
    local character = Ext.Entity.GetCharacter(characterHandle)
    if not character then
        logMessage("Error: Character not found for handle " .. tostring(characterHandle))
        return
    end

    if not character.SpellBook or not character.SpellBook.HasSpell[0][VANILLA_SPELL] then
        Ext.Entity.AddSpell(characterHandle, VANILLA_SPELL, 0)
        logMessage("Added " .. VANILLA_SPELL .. " to " .. (character.Data and character.Data.Name or tostring(characterHandle)))
    else
        logMessage((character.Data and character.Data.Name or tostring(characterHandle)) .. " already has " .. VANILLA_SPELL)
    end
end

-- Remove the spell from a character
local function RemoveSpell(characterHandle)
    local character = Ext.Entity.GetCharacter(characterHandle)
    if not character then
        logMessage("Error: Character not found for handle " .. tostring(characterHandle))
        return
    end

    if character.SpellBook and character.SpellBook.HasSpell[0][VANILLA_SPELL] then
        Ext.Entity.RemoveSpell(characterHandle, VANILLA_SPELL, 0)
        logMessage("Removed " .. VANILLA_SPELL .. " from " .. (character.Data and character.Data.Name or tostring(characterHandle)))
    else
        logMessage((character.Data and character.Data.Name or tostring(characterHandle)) .. " does not have " .. VANILLA_SPELL)
    end
end

-- Register Osiris event listeners
if Ext.Osiris.IsCallable() then
    logMessage("Registering Osiris listeners in server context")
    
    Ext.Osiris.RegisterListener("ItemEquipped", 4, "after", function(characterHandle, itemHandle, slotType, success)
        logMessage("ItemEquipped: character=" .. tostring(characterHandle) .. ", item=" .. tostring(itemHandle) .. ", slot=" .. tostring(slotType) .. ", success=" .. tostring(success))
        if success and slotType == "Weapon" and IsGreatsword(itemHandle) then
            AddSpell(characterHandle)
        end
    end)

    Ext.Osiris.RegisterListener("ItemUnequipped", 4, "after", function(characterHandle, itemHandle, slotType, success)
        logMessage("ItemUnequipped: character=" .. tostring(characterHandle) .. ", item=" .. tostring(itemHandle) .. ", slot=" .. tostring(slotType) .. ", success=" .. tostring(success))
        if success and slotType == "Weapon" and IsGreatsword(itemHandle) then
            RemoveSpell(characterHandle)
        end
    end)

    Ext.Osiris.RegisterListener("GameStarted", 1, "after", function(_)
        logMessage("GameStarted: Checking equipped items")
        for _, characterHandle in ipairs(Ext.Entity.GetAllCharacterHandles()) do
            local character = Ext.Entity.GetCharacter(characterHandle)
            if character and character.IsPlayer then
                local mainHand = character.Equipment and character.Equipment.Slots.Weapon
                if mainHand and IsGreatsword(mainHand) then
                    AddSpell(characterHandle)
                end
            end
        end
    end)

    logMessage("Osiris listeners registered successfully")
else
    logMessage("Error: Osiris not available, likely running in client context")
end

logMessage("GreatswordAbilityInjector.lua loaded successfully")