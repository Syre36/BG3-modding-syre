-- BootstrapServer.lua
Ext.Utils.Print("[Arsenal_Overhaul] Loading server-side bootstrap")
Ext.LuaRequire("Public/Arsenal_Overhaul/ScriptExtender/Lua/GreatswordAbilityInjector")
Ext.Utils.Print("[Arsenal_Overhaul] Server-side bootstrap loaded")